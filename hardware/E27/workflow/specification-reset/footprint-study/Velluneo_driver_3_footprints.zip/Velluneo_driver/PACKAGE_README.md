# Native schematic and three footprint candidates

Open Velluneo_specification_reset.kicad_pro in KiCad10.0.6. U1/BR1/Q1 now reference the included local footprint library. Other25items remain without selected footprints. No productPCB, copper, release, assembly qualification or measuredoperation is included. Full workflow and unchanged open electrical findings remain in the device repository. Start with footprint-study/README.md for actual source and check limits.
