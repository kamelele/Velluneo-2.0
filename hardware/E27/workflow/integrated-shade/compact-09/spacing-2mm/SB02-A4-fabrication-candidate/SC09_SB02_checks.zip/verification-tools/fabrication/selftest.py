"""Synthetic parser/multiset controls; no CAD saves or fabrication exports."""
from pathlib import Path
import json
import formats as f
import audit_fabrication as a
H=Path(__file__).resolve().parent;O=H/'synthetic-fixtures';O.mkdir(exist_ok=True)
prefix='%TF.FileFunction,Copper,L1,Top*%\n%TF.FilePolarity,Positive*%\n%FSLAX46Y46*%\n%MOMM*%\n%LPD*%\nG01*\n'
line=prefix+'%TA.AperFunction,Conductor*%\n%ADD10C,0.400000*%\n%TD*%\nD10*\nX0Y0D02*\nX1000000Y0D01*\nM02*\n'
flash=prefix+'%TA.AperFunction,SMDPad,CuDef*%\n%ADD10R,1.000000X2.000000*%\n%TD*%\nD10*\n%TO.P,D1,K*%\n%TO.N,/SW*%\nX1000000Y1000000D03*\nX4000000Y1000000D03*\nM02*\n'
cases={}
for name,text,expected in [('line_positive',line,True),('flash_duplicate_positive',flash,True),('arc_rejected',line.replace('G01*','G02*',1),False),('partial_coordinate_rejected',line.replace('X1000000Y0D01*','X1000000D01*'),False),('inch_rejected',line.replace('%MOMM*%','%MOIN*%'),False),('unsupported_aperture_rejected',line.replace('ADD10C,0.400000','ADD10P,0.400000X6'),False),('missing_end_rejected',line.replace('M02*',''),False),('changed_macro_rejected',prefix+'%AMRoundRect*\n1,1,99,0,0*%\nM02*\n',False)]:
    p=O/(name+'.gbr');p.write_text(text);error=None
    try:parsed=f.gerber(p);accepted=True
    except Exception as e:accepted=False;error=str(e)
    cases[name]={'test_passed':accepted==expected,'accepted':accepted,'error':error}
parsed=f.gerber(O/'flash_duplicate_positive.gbr');actual=[('F.Cu',*o['ref'],a.pt(o['position']),a.geometry(f.aperture_geometry(o['aperture'])),o['net'])for o in parsed['operations']]
cases['duplicate_contact_missing_detected']={'test_passed':not a.diff(actual,actual[:1])['passed'],'missing_count':len(a.diff(actual,actual[:1])['missing'])}
cases['layer_swap_detected']={'test_passed':not a.diff([a.segment('F.Cu',(0,0),(1,0),.4)],[a.segment('B.Cu',(0,0),(1,0),.4)])['passed']}
hit={'position':(1.,2.),'diameter':.3,'plated':True};cases['duplicate_drill_missing_detected']={'test_passed':not a.drill_match([hit,hit],[hit])['passed']}
text='M48\nFMAT,2\nMETRIC\n; #@! TF.FileFunction,Plated,1,2,PTH\nT1C0.300\n%\nG90\nG05\nT1\nX1.0Y-2.0\nM30\n';p=O/'positive.drl';p.write_text(text);cases['decimal_drill_positive']={'test_passed':f.excellon(p)['hits']==[{'position':(1.,2.),'diameter':.3}]}
text=text.replace('X1.0Y-2.0','G85X1.0Y-2.0');p=O/'slot.drl';p.write_text(text)
try:f.excellon(p);rejected=False
except f.Unsupported:rejected=True
cases['slot_rejected']={'test_passed':rejected}
ok=all(x['test_passed']for x in cases.values());report={'synthetic_only':True,'tests_passed':ok,'no_CAD_export_or_save':True,'checker_sha256':a.sha(a.__file__),'formats_sha256':a.sha(f.__file__),'cases':cases};a.dump(H/'selftest-report.json',report);print(json.dumps(report,indent=2));raise SystemExit(0 if ok else 1)
