# Private fabrication audit extension handoff

Actor adopt_checker_15, bounded implementer. All writes confined to this directory.
No source, shared fabrication tool, raw native export, job file, drill or profile
was modified. Root owns integration. This is an implementation candidate requiring
independent review; the author does not approve fabrication or product release.

## Diagnosis and exact delta

Final native board SHA256
`c75423f934b637d8b381745e72bed8440eceddb5020b956ee01f4b4426647564`
has native solder mask minimum width **zero** and source plot error .005 mm.
Final F.Mask contains 41 flashes, B.Mask 70 flashes. The prior checker accepts only
region mask geometry and assumes a strictly positive closing width. It stops even
though its format reader already supports these checked native flash apertures.

The existing pinned native plotting source
`../fab-numeric-review/plot_board_layers-10.0.6.cpp`, SHA256
`a9dbb147d4fd2befa8b963526ec8e74ec3a20ff1044dacb41937dcc6d28597d0`,
lines 93–106 explicitly selects standard PlotLayer when mask min-width is zero;
otherwise it selects GenerateLayerPoly and its existing closing operation.
The private predictor preserves the old positive-width branch and adds the zero
branch from native pad openings, same native mask expansions and untented vias.
Mask artwork, mask zones, unknown primitives, negative native min-width and
unsupported features continue to stop.

`mask_geometry` converts checked C/R/O/exact RoundRect flash definitions into
polygons and composes dark/clear operations in order, also retaining region support.
Negative file polarity means dark geometry describes openings; the existing file
polarity check remains mandatory. Circle/rectangle/oval/roundrect sizes and radius
are validated; line mask geometry is rejected rather than omitted. Native polygon
approximation uses .001 mm on plotted flashes and the existing source error on
expected geometry. The **existing .012 mm comparison envelope**, **.1 mm mask web**,
copper edge, electrical rules and all copper/drill identity multisets are unchanged.

After this mask fix the audit exposed an unrelated inclusive drill endpoint:
native `(111.3752,116.8225)` versus plotted `(111.375,116.822)`, one via. Binary float
subtraction spuriously exceeds .0005 despite exact decimal Y difference .0005.
Root explicitly authorized exact-decimal coordinate comparison preserving the
same .0005 per-axis bound. `drill_match` now compares `Decimal(str(coordinate))`
and `Decimal(str(tol))`; no epsilon or tolerance enlargement is introduced.
Plating, diameter comparison, duplicate hits and one-to-one matching remain intact.

## Frozen candidate and evidence

- Candidate `audit_fabrication.py`: `24c9c09bb82d58baf93eb8a663bdd3c9fa066dfac5aad5d611a46df1ff10fa1b`
- Integration patch `audit_fabrication.patch`: `21838572820acb5da63f28c612577d8a5d13bcfcff3d16eb4510d827e3f28a47`
- `test-results.json`: `00a8232e87e1a43ac81d4a58078f3b317f92041be077e8752e24a9edb1a074db`
- `final-positive.json`: `c41f2e8021288ec486db523a233688f0c6c7dc4965273145baf0a1be5691cae9`
- `negative-displaced-mask.json`: `8d0a156770af18a6510fe7e28f54000c0e615e2706491ed2317d3852375636f8`
- `historical-regression.json`: `82162d7e7a67470c11d27e4d96dd221a3be75bffb539a48d06ebbf50989e7d4e`
- `selftest-report.json`: `138bf05d28556e972f596a8d1bea4a3ab6dc86fec01f71a7d78cc72432ebc1f1`

Run with pinned KiCad 10.0.6 Python after loading work/sc08-env.ps1:

    & $CadPy work/sc09-spacing23/fab-mask-flash-review/run_tests.py
    & $CadPy work/sc09-spacing23/fab-mask-flash-review/selftest.py

Actual results: 14/14 targeted cases and all inherited parser/multiset cases pass.
The actual final source/raw export full audit passes. Both masks have zero polygon
residual outside .012 mm; minimum separate webs F.Mask .75425 mm and B.Mask .37 mm.
All 49 drills match including the exact .0005 mm coordinate boundary. The historical
source/export full audit also passes, exercising the unchanged closing branch.
A private raw Gerber copy with every B.Mask flash translated **.05 mm in X** fails
only `mask_profile B.Mask mismatch`; no source or original export was changed.
Drill just-inside .000499, boundary .000500 and outside .000501 mm controls behave
as required. Duplicate holes remain detected. Unsupported mask line, negative
dimension and unknown polarity stop. C/R/O/RoundRect shapes and sequential
dark-then-clear subtraction are checked. Every frozen input hash remains unchanged,
including the shared checker, source, profile and all final export files.

Independent review and fresh checks after root integration are required. This
does not establish electrical performance, physical insulation, thermal/EMC
qualification, approval of artwork, supplier ordering or fabrication release.
